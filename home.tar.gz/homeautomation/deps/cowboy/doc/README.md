Cowboy documentation
====================

Documentation for Cowboy is available online at the following addresses:

 *  [README](http://ninenines.eu/docs/en/cowboy/HEAD/README)
 *  [User Guide](http://ninenines.eu/docs/en/cowboy/HEAD/guide/introduction)

This folder is used for generating the Reference Manual. You can generate
it yourself by typing `make docs` in the top-level Cowboy directory.
