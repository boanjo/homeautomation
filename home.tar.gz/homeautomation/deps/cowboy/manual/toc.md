Cowboy Function Reference
=========================

The function reference documents the public interface of Cowboy.

 *  [The Cowboy Application](cowboy_app.md)
 *  [cowboy](cowboy.md)
 *  [cowboy_handler](cowboy_handler.md)
 *  [cowboy_http_handler](cowboy_http_handler.md)
 *  [cowboy_loop_handler](cowboy_loop_handler.md)
 *  [cowboy_middleware](cowboy_middleware.md)
 *  [cowboy_protocol](cowboy_protocol.md)
 *  [cowboy_req](cowboy_req.md)
 *  [cowboy_rest](cowboy_rest.md)
 *  [cowboy_router](cowboy_router.md)
 *  [cowboy_sub_protocol](cowboy_sub_protocol.md)
 *  [cowboy_websocket](cowboy_websocket.md)
 *  [cowboy_websocket_handler](cowboy_websocket_handler.md)
