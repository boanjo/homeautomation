Cowboy websocket
================

To compile this example you need rebar in your PATH.

Type the following command:
```
$ rebar get-deps compile
```

You can then start the Erlang node with the following command:
```
./start.sh
```

Then point your browser to the indicated URL to open a websocket client.
Not all browsers support websockets. It was tested with Chromium.
