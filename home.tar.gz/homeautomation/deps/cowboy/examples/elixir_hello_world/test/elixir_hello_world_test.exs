Code.require_file "../test_helper.exs", __FILE__

defmodule ElixirHelloWorldTest do
  use ExUnit.Case

  test "the truth" do
    assert true
  end
end
