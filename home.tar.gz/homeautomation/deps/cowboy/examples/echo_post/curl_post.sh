#!/bin/sh
curl -i -d echo=$1 http://localhost:8080
